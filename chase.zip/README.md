# chase

Fivem Script for creating a chase game, see in game help for commands
